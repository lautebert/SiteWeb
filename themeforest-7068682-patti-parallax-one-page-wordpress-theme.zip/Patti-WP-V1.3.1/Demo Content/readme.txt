This folder contains the files for importing the demo content.
As a suggestion, I recommend you import only "Sliders", "Patti-All Content" and "Patti-VC-templates".

If you don`t want to import all the content, you can use the rest of the files from "Individual Import Files" to import separate sections, like portfolio projects. 

"Patti-VC-Templates" contains templates for homepage sections and projects and is a file that you need to import, for sure.

Thank you!

